import { defineConfig } from "vite";
import { resolve } from "node:path";
import site from "./site.config.js";
import { formatHoursSummary, openingHoursSchema } from "./src/hours.js";

const cleanUrl = site.siteUrl.replace(/\/$/, "");
const address = {
  "@type": "PostalAddress",
  streetAddress: site.contact.address,
  addressLocality: site.contact.city,
  addressRegion: site.contact.state,
  addressCountry: "NG",
  ...(site.contact.postalCode ? { postalCode: site.contact.postalCode } : {}),
};
const social = Object.values(site.social).filter(Boolean);
const heroImage = `${cleanUrl}/assets/images/og-image.jpg`;

const schema = {
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "WebSite",
      "@id": `${cleanUrl}/#website`,
      url: `${cleanUrl}/`,
      name: site.name,
      description: site.description,
      inLanguage: "en-NG",
    },
    {
      "@type": "Restaurant",
      "@id": `${cleanUrl}/#restaurant`,
      name: `${site.name} Restaurant`,
      url: `${cleanUrl}/#restaurant`,
      image: heroImage,
      description: "Sample restaurant description — replace with the final venue description.",
      telephone: site.contact.phone,
      email: site.contact.email,
      address,
      servesCuisine: ["Nigerian", "International"],
      priceRange: "₦₦₦",
      acceptsReservations: true,
      openingHoursSpecification: openingHoursSchema(site.hours.restaurant),
      sameAs: social,
    },
    {
      "@type": "Hotel",
      "@id": `${cleanUrl}/#hotel`,
      name: `${site.name} Hotel`,
      url: `${cleanUrl}/#rooms`,
      image: heroImage,
      description: "Sample boutique hotel description — replace with final room and property details.",
      telephone: site.contact.phone,
      email: site.contact.email,
      address,
      checkinTime: site.hotel.checkInTime,
      checkoutTime: site.hotel.checkOutTime,
      openingHoursSpecification: openingHoursSchema(site.hours.hotel),
      amenityFeature: [
        "Free Wi-Fi",
        "Air conditioning",
        "Room service",
        "Daily housekeeping",
      ].map((name) => ({ "@type": "LocationFeatureSpecification", name, value: true })),
      sameAs: social,
    },
  ],
};

const replacements = {
  SITE_NAME: site.name,
  SITE_SHORT_NAME: site.shortName,
  SITE_TAGLINE: site.tagline,
  SITE_DESCRIPTION: site.description,
  SITE_URL: cleanUrl,
  SITE_LOCALE: site.locale,
  PHONE_DISPLAY: site.contact.phoneDisplay,
  PHONE: site.contact.phone,
  WHATSAPP: site.contact.whatsapp,
  EMAIL: site.contact.email,
  ADDRESS: `${site.contact.address}, ${site.contact.city}, ${site.contact.state}`,
  CITY: site.contact.city,
  MAP_LINK: site.contact.mapLink,
  INSTAGRAM_URL: site.social.instagram,
  FACEBOOK_URL: site.social.facebook,
  X_URL: site.social.x,
  HOTEL_CHECKIN: site.hotel.checkInTime,
  HOTEL_CHECKOUT: site.hotel.checkOutTime,
  HOURS_RESTAURANT: formatHoursSummary(site.hours.restaurant),
  HOURS_OPEN_LOUNGE: formatHoursSummary(site.hours.openLounge),
  HOURS_VVIP: formatHoursSummary(site.hours.vvip),
  HOURS_SNOOKER: formatHoursSummary(site.hours.snooker),
  HOURS_HOTEL: formatHoursSummary(site.hours.hotel),
  SCHEMA_JSON: JSON.stringify(schema).replace(/</g, "\\u003c"),
};

function injectSiteConfig() {
  return {
    name: "inject-site-config",
    transformIndexHtml(html) {
      return html.replace(/%%([A-Z0-9_]+)%%/g, (match, key) => {
        if (!(key in replacements)) return match;
        if (key === "SCHEMA_JSON") return replacements[key];
        return String(replacements[key])
          .replace(/&/g, "&amp;")
          .replace(/</g, "&lt;")
          .replace(/>/g, "&gt;")
          .replace(/"/g, "&quot;");
      });
    },
    generateBundle() {
      this.emitFile({
        type: "asset",
        fileName: "robots.txt",
        source: `User-agent: *\nAllow: /\n\nSitemap: ${cleanUrl}/sitemap.xml\n`,
      });
      this.emitFile({
        type: "asset",
        fileName: "sitemap.xml",
        source: `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n  <url><loc>${cleanUrl}/</loc></url>\n</urlset>\n`,
      });
      this.emitFile({
        type: "asset",
        fileName: "site.webmanifest",
        source: JSON.stringify({
          name: site.name,
          short_name: site.shortName,
          description: site.description,
          start_url: "/",
          display: "standalone",
          background_color: "#0b0b0a",
          theme_color: "#0b0b0a",
          icons: [
            { src: "/favicon-192.png", sizes: "192x192", type: "image/png" },
            { src: "/favicon-512.png", sizes: "512x512", type: "image/png" },
          ],
        }),
      });
    },
  };
}

export default defineConfig({
  plugins: [injectSiteConfig()],
  server: {
    host: "0.0.0.0",
    allowedHosts: true,
  },
  preview: {
    host: "0.0.0.0",
    allowedHosts: true,
  },
  build: {
    target: "es2020",
    cssCodeSplit: false,
    rollupOptions: {
      input: {
        main: resolve(import.meta.dirname, "index.html"),
        notFound: resolve(import.meta.dirname, "404.html"),
        thanks: resolve(import.meta.dirname, "thanks.html"),
      },
    },
  },
});
